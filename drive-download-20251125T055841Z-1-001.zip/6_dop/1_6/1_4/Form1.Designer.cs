﻿
namespace _1_4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pane6 = new System.Windows.Forms.Panel();
            this.pane7 = new System.Windows.Forms.Panel();
            this.pane8 = new System.Windows.Forms.Panel();
            this.pane9 = new System.Windows.Forms.Panel();
            this.pane10 = new System.Windows.Forms.Panel();
            this.pane5 = new System.Windows.Forms.Panel();
            this.pane4 = new System.Windows.Forms.Panel();
            this.pane3 = new System.Windows.Forms.Panel();
            this.pane2 = new System.Windows.Forms.Panel();
            this.pane1 = new System.Windows.Forms.Panel();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            this.SuspendLayout();
            // 
            // trackBar1
            // 
            this.trackBar1.LargeChange = 1;
            this.trackBar1.Location = new System.Drawing.Point(196, 37);
            this.trackBar1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(368, 45);
            this.trackBar1.TabIndex = 1;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(55, 320);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(26, 28);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(55, 287);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(26, 28);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(55, 254);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(26, 28);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(55, 220);
            this.panel4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(26, 28);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(55, 187);
            this.panel5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(26, 28);
            this.panel5.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(55, 154);
            this.panel6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(26, 28);
            this.panel6.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(55, 120);
            this.panel7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(26, 28);
            this.panel7.TabIndex = 6;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(55, 87);
            this.panel8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(26, 28);
            this.panel8.TabIndex = 7;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Location = new System.Drawing.Point(55, 54);
            this.panel9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(26, 28);
            this.panel9.TabIndex = 8;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Location = new System.Drawing.Point(55, 20);
            this.panel10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(26, 28);
            this.panel10.TabIndex = 4;
            // 
            // pane6
            // 
            this.pane6.BackColor = System.Drawing.Color.White;
            this.pane6.Location = new System.Drawing.Point(102, 154);
            this.pane6.Margin = new System.Windows.Forms.Padding(2);
            this.pane6.Name = "pane6";
            this.pane6.Size = new System.Drawing.Size(26, 28);
            this.pane6.TabIndex = 26;
            // 
            // pane7
            // 
            this.pane7.BackColor = System.Drawing.Color.White;
            this.pane7.Location = new System.Drawing.Point(102, 120);
            this.pane7.Margin = new System.Windows.Forms.Padding(2);
            this.pane7.Name = "pane7";
            this.pane7.Size = new System.Drawing.Size(26, 28);
            this.pane7.TabIndex = 27;
            // 
            // pane8
            // 
            this.pane8.BackColor = System.Drawing.Color.White;
            this.pane8.Location = new System.Drawing.Point(102, 87);
            this.pane8.Margin = new System.Windows.Forms.Padding(2);
            this.pane8.Name = "pane8";
            this.pane8.Size = new System.Drawing.Size(26, 28);
            this.pane8.TabIndex = 28;
            // 
            // pane9
            // 
            this.pane9.BackColor = System.Drawing.Color.White;
            this.pane9.Location = new System.Drawing.Point(102, 54);
            this.pane9.Margin = new System.Windows.Forms.Padding(2);
            this.pane9.Name = "pane9";
            this.pane9.Size = new System.Drawing.Size(26, 28);
            this.pane9.TabIndex = 29;
            // 
            // pane10
            // 
            this.pane10.BackColor = System.Drawing.Color.White;
            this.pane10.Location = new System.Drawing.Point(102, 20);
            this.pane10.Margin = new System.Windows.Forms.Padding(2);
            this.pane10.Name = "pane10";
            this.pane10.Size = new System.Drawing.Size(26, 28);
            this.pane10.TabIndex = 25;
            // 
            // pane5
            // 
            this.pane5.BackColor = System.Drawing.Color.White;
            this.pane5.Location = new System.Drawing.Point(102, 187);
            this.pane5.Margin = new System.Windows.Forms.Padding(2);
            this.pane5.Name = "pane5";
            this.pane5.Size = new System.Drawing.Size(26, 28);
            this.pane5.TabIndex = 21;
            // 
            // pane4
            // 
            this.pane4.BackColor = System.Drawing.Color.White;
            this.pane4.Location = new System.Drawing.Point(102, 220);
            this.pane4.Margin = new System.Windows.Forms.Padding(2);
            this.pane4.Name = "pane4";
            this.pane4.Size = new System.Drawing.Size(26, 28);
            this.pane4.TabIndex = 22;
            // 
            // pane3
            // 
            this.pane3.BackColor = System.Drawing.Color.White;
            this.pane3.Location = new System.Drawing.Point(102, 254);
            this.pane3.Margin = new System.Windows.Forms.Padding(2);
            this.pane3.Name = "pane3";
            this.pane3.Size = new System.Drawing.Size(26, 28);
            this.pane3.TabIndex = 23;
            // 
            // pane2
            // 
            this.pane2.BackColor = System.Drawing.Color.White;
            this.pane2.Location = new System.Drawing.Point(102, 287);
            this.pane2.Margin = new System.Windows.Forms.Padding(2);
            this.pane2.Name = "pane2";
            this.pane2.Size = new System.Drawing.Size(26, 28);
            this.pane2.TabIndex = 24;
            // 
            // pane1
            // 
            this.pane1.BackColor = System.Drawing.Color.White;
            this.pane1.Location = new System.Drawing.Point(102, 320);
            this.pane1.Margin = new System.Windows.Forms.Padding(2);
            this.pane1.Name = "pane1";
            this.pane1.Size = new System.Drawing.Size(26, 28);
            this.pane1.TabIndex = 20;
            // 
            // trackBar2
            // 
            this.trackBar2.LargeChange = 1;
            this.trackBar2.Location = new System.Drawing.Point(196, 103);
            this.trackBar2.Margin = new System.Windows.Forms.Padding(2);
            this.trackBar2.Maximum = 100;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(368, 45);
            this.trackBar2.TabIndex = 30;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(276, 225);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 57);
            this.button1.TabIndex = 31;
            this.button1.Text = "Случайные значения";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.trackBar2);
            this.Controls.Add(this.pane6);
            this.Controls.Add(this.pane7);
            this.Controls.Add(this.pane8);
            this.Controls.Add(this.pane9);
            this.Controls.Add(this.pane10);
            this.Controls.Add(this.pane5);
            this.Controls.Add(this.pane4);
            this.Controls.Add(this.pane3);
            this.Controls.Add(this.pane2);
            this.Controls.Add(this.pane1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.trackBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Вертикальный прогресс бар";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel pane6;
        private System.Windows.Forms.Panel pane7;
        private System.Windows.Forms.Panel pane8;
        private System.Windows.Forms.Panel pane9;
        private System.Windows.Forms.Panel pane10;
        private System.Windows.Forms.Panel pane5;
        private System.Windows.Forms.Panel pane4;
        private System.Windows.Forms.Panel pane3;
        private System.Windows.Forms.Panel pane2;
        private System.Windows.Forms.Panel pane1;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.Button button1;
    }
}

